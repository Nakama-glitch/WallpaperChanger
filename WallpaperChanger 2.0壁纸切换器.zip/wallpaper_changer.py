import os
import sys
import json
import shutil
import ctypes
from ctypes import wintypes
import winreg
import webbrowser
import tkinter as tk
from tkinter import messagebox, colorchooser

# Windows API 常量
SPI_SETDESKWALLPAPER = 0x0014
SPIF_UPDATEINIFILE = 0x01
SPIF_SENDCHANGE = 0x02

SUPPORTED_EXTS = ('.jpg', '.jpeg', '.png', '.bmp', '.gif', '.tif', '.tiff')

# 加载 Windows 原生 GDI+
gdiplus = ctypes.windll.gdiplus


class GdiplusStartupInput(ctypes.Structure):
    _fields_ = [
        ("GdiplusVersion", wintypes.UINT),
        ("DebugEventCallback", ctypes.c_void_p),
        ("SuppressBackgroundThread", wintypes.BOOL),
        ("SuppressExternalCodecs", wintypes.BOOL),
    ]


class GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", wintypes.DWORD),
        ("Data2", wintypes.WORD),
        ("Data3", wintypes.WORD),
        ("Data4", wintypes.BYTE * 8),
    ]


# PNG 编码器 CLSID
CLSID_PNG = GUID(0x557CF406, 0x1A04, 0x11D3, (0x9A, 0x73, 0x00, 0x00, 0xF8, 0x1E, 0xF3, 0x2E))

# 显式声明 64 位指针参数签名
gdiplus.GdiplusStartup.argtypes = [ctypes.POINTER(ctypes.c_ulonglong), ctypes.POINTER(GdiplusStartupInput), ctypes.c_void_p]
gdiplus.GdipLoadImageFromFile.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_void_p)]
gdiplus.GdipGetImageWidth.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.UINT)]
gdiplus.GdipGetImageHeight.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.UINT)]
gdiplus.GdipDisposeImage.argtypes = [ctypes.c_void_p]
gdiplus.GdipGetImageThumbnail.argtypes = [ctypes.c_void_p, wintypes.UINT, wintypes.UINT, ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p, ctypes.c_void_p]
gdiplus.GdipBitmapGetPixel.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.POINTER(wintypes.DWORD)]
gdiplus.GdipCreateBitmapFromScan0.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
gdiplus.GdipGetImageGraphicsContext.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
gdiplus.GdipSetInterpolationMode.argtypes = [ctypes.c_void_p, ctypes.c_int]
gdiplus.GdipGraphicsClear.argtypes = [ctypes.c_void_p, wintypes.DWORD]
gdiplus.GdipDrawImageRectI.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int]
gdiplus.GdipSaveImageToFile.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR, ctypes.POINTER(GUID), ctypes.c_void_p]
gdiplus.GdipDeleteGraphics.argtypes = [ctypes.c_void_p]


def hex_to_argb(hex_color):
    hex_color = hex_color.lstrip('#')
    r = int(hex_color[0:2], 16)
    g = int(hex_color[2:4], 16)
    b = int(hex_color[4:6], 16)
    return (0xFF << 24) | (r << 16) | (g << 8) | b


class NativeImageEngine:
    """基于 Windows 原生 GDI+ 的零依赖图像处理引擎"""
    def __init__(self):
        self.token = ctypes.c_ulonglong()
        startup_input = GdiplusStartupInput(1, None, False, False)
        gdiplus.GdiplusStartup(ctypes.byref(self.token), ctypes.byref(startup_input), None)

    def get_image_size(self, path):
        img = ctypes.c_void_p()
        if gdiplus.GdipLoadImageFromFile(path, ctypes.byref(img)) != 0:
            return None
        w = wintypes.UINT()
        h = wintypes.UINT()
        gdiplus.GdipGetImageWidth(img, ctypes.byref(w))
        gdiplus.GdipGetImageHeight(img, ctypes.byref(h))
        gdiplus.GdipDisposeImage(img)
        return w.value, h.value

    def extract_auto_color(self, path):
        """提取图片主色调（缩小为 1x1 采样平均色）"""
        img = ctypes.c_void_p()
        if gdiplus.GdipLoadImageFromFile(path, ctypes.byref(img)) != 0:
            return "#000000"
        thumb = ctypes.c_void_p()
        gdiplus.GdipGetImageThumbnail(img, 1, 1, ctypes.byref(thumb), None, None)
        argb = wintypes.DWORD()
        if thumb:
            gdiplus.GdipBitmapGetPixel(thumb, 0, 0, ctypes.byref(argb))
            gdiplus.GdipDisposeImage(thumb)
        gdiplus.GdipDisposeImage(img)
        val = argb.value
        r = (val >> 16) & 0xFF
        g = (val >> 8) & 0xFF
        b = val & 0xFF
        return f"#{r:02x}{g:02x}{b:02x}"

    def render_canvas(self, src_path, out_path, canvas_w, canvas_h, scale, offset_x, offset_y, bg_hex):
        """合成指定尺寸画布并导出为标准 PNG"""
        src_img = ctypes.c_void_p()
        if gdiplus.GdipLoadImageFromFile(src_path, ctypes.byref(src_img)) != 0:
            return False

        orig_w = wintypes.UINT()
        orig_h = wintypes.UINT()
        gdiplus.GdipGetImageWidth(src_img, ctypes.byref(orig_w))
        gdiplus.GdipGetImageHeight(src_img, ctypes.byref(orig_h))

        bmp = ctypes.c_void_p()
        gdiplus.GdipCreateBitmapFromScan0(canvas_w, canvas_h, 0, 0x21808, None, ctypes.byref(bmp))

        gfx = ctypes.c_void_p()
        gdiplus.GdipGetImageGraphicsContext(bmp, ctypes.byref(gfx))
        gdiplus.GdipSetInterpolationMode(gfx, 7)
        gdiplus.GdipGraphicsClear(gfx, hex_to_argb(bg_hex))

        new_w = max(1, int(orig_w.value * scale))
        new_h = max(1, int(orig_h.value * scale))
        draw_x = int((canvas_w - new_w) / 2 + offset_x)
        draw_y = int((canvas_h - new_h) / 2 + offset_y)

        gdiplus.GdipDrawImageRectI(gfx, src_img, draw_x, draw_y, new_w, new_h)

        status = gdiplus.GdipSaveImageToFile(bmp, out_path, ctypes.byref(CLSID_PNG), None)

        gdiplus.GdipDeleteGraphics(gfx)
        gdiplus.GdipDisposeImage(bmp)
        gdiplus.GdipDisposeImage(src_img)
        return status == 0

    def convert_to_png(self, src_path, out_path):
        img = ctypes.c_void_p()
        if gdiplus.GdipLoadImageFromFile(src_path, ctypes.byref(img)) != 0:
            return False
        status = gdiplus.GdipSaveImageToFile(img, out_path, ctypes.byref(CLSID_PNG), None)
        gdiplus.GdipDisposeImage(img)
        return status == 0


class WallpaperChangerPro:
    def __init__(self, root):
        self.root = root
        self.root.title("设为桌面背景 - 壁纸微调切换器")
        self.root.geometry("765x485")
        self.root.resizable(False, False)

        self.engine = NativeImageEngine()

        user32 = ctypes.windll.user32
        self.screen_w = user32.GetSystemMetrics(0)
        self.screen_h = user32.GetSystemMetrics(1)

        if getattr(sys, 'frozen', False):
            self.base_dir = os.path.dirname(sys.executable)
        else:
            self.base_dir = os.path.dirname(os.path.abspath(__file__))

        self.wallpaper_dir = os.path.join(self.base_dir, "壁纸")
        self.data_dir = os.path.join(self.base_dir, "data")
        os.makedirs(self.wallpaper_dir, exist_ok=True)
        os.makedirs(self.data_dir, exist_ok=True)

        self.config_path = os.path.join(self.data_dir, "config.json")
        self.backup_path = os.path.join(self.data_dir, "original_backup.png")
        self.rendered_path = os.path.join(self.data_dir, "rendered_wallpaper.png")
        self.preview_tmp_path = os.path.join(self.data_dir, "preview_tmp.png")

        self.config = self.load_config()
        self.backup_original_wallpaper()

        self.images = self.scan_images()
        self.current_filename = self.config.get("last_selected", "")

        if self.current_filename in self.images:
            self.current_index = self.images.index(self.current_filename)
        else:
            self.current_index = 0
            self.current_filename = self.images[0] if self.images else ""

        self.scale = 1.0
        self.offset_x = 0
        self.offset_y = 0
        self.bg_mode = tk.StringVar(value="black")
        self.custom_color = "#000000"
        self.is_restored = False
        self.has_changed_in_session = False

        self.setup_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

        # 绑定键盘左右方向键，方便快速预览上一张/下一张
        self.root.bind("<Left>", lambda e: self.preview_step(-1))
        self.root.bind("<Right>", lambda e: self.preview_step(1))

        if self.images:
            self.load_image_settings(self.current_filename)
            self.update_preview()
        else:
            self.status_var.set("请在【壁纸】文件夹中放入图片")

    def load_config(self):
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {"last_selected": "", "profiles": {}}

    def save_config(self):
        self.config["last_selected"] = self.current_filename
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def get_windows_current_wallpaper(self):
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Control Panel\Desktop", 0, winreg.KEY_READ)
            path, _ = winreg.QueryValueEx(key, "Wallpaper")
            winreg.CloseKey(key)
            return path
        except Exception:
            return ""

    def backup_original_wallpaper(self):
        curr = self.get_windows_current_wallpaper()
        if not curr or not os.path.exists(curr):
            return
        if os.path.abspath(curr) == os.path.abspath(self.rendered_path):
            return
        if not self.engine.convert_to_png(curr, self.backup_path):
            try:
                shutil.copy2(curr, self.backup_path)
            except Exception:
                pass

    def scan_images(self):
        files = []
        for f in os.listdir(self.wallpaper_dir):
            full_path = os.path.join(self.wallpaper_dir, f)
            if os.path.isfile(full_path) and f.lower().endswith(SUPPORTED_EXTS):
                files.append(f)
        files.sort(key=lambda x: x.lower())
        return files

    def setup_ui(self):
        # 底部品牌署名栏
        footer_frame = tk.Frame(self.root, padx=16, pady=6)
        footer_frame.pack(side=tk.BOTTOM, fill=tk.X)

        sep = tk.Frame(footer_frame, height=1, bg="#DCDCDC")
        sep.pack(fill=tk.X, pady=(0, 5))

        brand_row = tk.Frame(footer_frame)
        brand_row.pack(fill=tk.X)

        lbl_tip = tk.Label(
            brand_row,
            text="提示：点击 ← / → 仅预览切换，点击蓝色按钮应用到桌面",
            font=("Microsoft YaHei UI", 8),
            fg="#888888"
        )
        lbl_tip.pack(side=tk.LEFT)

        lbl_brand = tk.Label(
            brand_row,
            text="成遇知 | YouTube：www.youtube.com/@cyzhi",
            font=("Microsoft YaHei UI", 8),
            fg="#666666",
            cursor="hand2"
        )
        lbl_brand.pack(side=tk.RIGHT)
        lbl_brand.bind("<Button-1>", lambda e: webbrowser.open("https://www.youtube.com/@cyzhi"))
        lbl_brand.bind("<Enter>", lambda e: lbl_brand.config(fg="#0078D7"))
        lbl_brand.bind("<Leave>", lambda e: lbl_brand.config(fg="#666666"))

        # 主体内容区（修复 pady 为单值）
        main_frame = tk.Frame(self.root, padx=15, pady=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # 左侧预览框
        left_frame = tk.LabelFrame(main_frame, text=" 预览 ", font=("Microsoft YaHei UI", 9), padx=10, pady=10)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.preview_w = 460
        self.preview_h = int(self.preview_w * (self.screen_h / self.screen_w))
        self.canvas = tk.Canvas(
            left_frame,
            width=self.preview_w,
            height=self.preview_h,
            bg="#000000",
            highlightthickness=1,
            highlightbackground="#CCCCCC"
        )
        self.canvas.pack(pady=(5, 10))

        self.status_var = tk.StringVar(value="就绪")
        lbl_info = tk.Label(
            left_frame,
            textvariable=self.status_var,
            font=("Microsoft YaHei UI", 9),
            fg="#444444",
            anchor="w"
        )
        lbl_info.pack(fill=tk.X, pady=(2, 0))

        # 右侧控制面板
        right_frame = tk.Frame(main_frame, width=235, padx=12)
        right_frame.pack(side=tk.RIGHT, fill=tk.Y)
        right_frame.pack_propagate(False)

        # 1. 背景颜色
        bg_group = tk.LabelFrame(right_frame, text=" 背景颜色 ", font=("Microsoft YaHei UI", 9), padx=12, pady=8)
        bg_group.pack(fill=tk.X, pady=(0, 10))

        tk.Radiobutton(
            bg_group, text="黑色", variable=self.bg_mode, value="black",
            font=("Microsoft YaHei UI", 9), command=self.on_param_changed
        ).pack(anchor="w")

        tk.Radiobutton(
            bg_group, text="自动 (提取图片主色)", variable=self.bg_mode, value="auto",
            font=("Microsoft YaHei UI", 9), command=self.on_param_changed
        ).pack(anchor="w")

        custom_row = tk.Frame(bg_group)
        custom_row.pack(fill=tk.X, anchor="w")
        tk.Radiobutton(
            custom_row, text="自定义...", variable=self.bg_mode, value="custom",
            font=("Microsoft YaHei UI", 9), command=self.choose_custom_color
        ).pack(side=tk.LEFT)
        self.color_swatch = tk.Label(custom_row, width=3, bg=self.custom_color, relief="solid", bd=1)
        self.color_swatch.pack(side=tk.LEFT, padx=6)

        # 2. 位置微调与缩放按钮
        ctrl_frame = tk.Frame(right_frame, pady=4)
        ctrl_frame.pack(fill=tk.X, pady=(0, 6))

        dpad = tk.Frame(ctrl_frame)
        dpad.pack(side=tk.LEFT, padx=(2, 8))

        btn_style = {"font": ("Microsoft YaHei UI", 9, "bold"), "width": 3, "height": 1, "cursor": "hand2"}
        tk.Button(dpad, text="^", command=lambda: self.move_image(0, -30), **btn_style).grid(row=0, column=1, pady=2)
        tk.Button(dpad, text="<", command=lambda: self.move_image(-30, 0), **btn_style).grid(row=1, column=0, padx=2)
        tk.Button(dpad, text="•", command=self.reset_transform, **btn_style).grid(row=1, column=1, padx=2, pady=2)
        tk.Button(dpad, text=">", command=lambda: self.move_image(30, 0), **btn_style).grid(row=1, column=2, padx=2)
        tk.Button(dpad, text="v", command=lambda: self.move_image(0, 30), **btn_style).grid(row=2, column=1, pady=2)

        zoom_pad = tk.Frame(ctrl_frame)
        zoom_pad.pack(side=tk.RIGHT, padx=(4, 2))
        tk.Button(zoom_pad, text="+", command=lambda: self.zoom_image(0.05), **btn_style).pack(side=tk.LEFT, padx=2)
        tk.Button(zoom_pad, text="-", command=lambda: self.zoom_image(-0.05), **btn_style).pack(side=tk.LEFT, padx=2)

        # 3. 底部核心操作区（含 ← / → 预览浏览按钮）
        action_frame = tk.Frame(right_frame)
        action_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=(4, 2))

        nav_row = tk.Frame(action_frame)
        nav_row.pack(fill=tk.X, pady=(0, 7))

        tk.Button(
            nav_row,
            text="← 上一张预览",
            font=("Microsoft YaHei UI", 8),
            width=12,
            pady=3,
            cursor="hand2",
            command=lambda: self.preview_step(-1)
        ).pack(side=tk.LEFT)

        tk.Button(
            nav_row,
            text="下一张预览 →",
            font=("Microsoft YaHei UI", 8),
            width=12,
            pady=3,
            cursor="hand2",
            command=lambda: self.preview_step(1)
        ).pack(side=tk.RIGHT)

        tk.Button(
            action_frame,
            text="应用当前布局 (锁定记忆)",
            font=("Microsoft YaHei UI", 9, "bold"),
            bg="#0078D7",
            fg="white",
            activebackground="#005A9E",
            activeforeground="white",
            cursor="hand2",
            pady=5,
            command=self.apply_current_wallpaper
        ).pack(fill=tk.X, pady=(0, 7))

        bottom_row = tk.Frame(action_frame)
        bottom_row.pack(fill=tk.X)

        tk.Button(
            bottom_row,
            text="切换壁纸",
            font=("Microsoft YaHei UI", 9),
            width=11,
            pady=4,
            cursor="hand2",
            command=self.next_wallpaper
        ).pack(side=tk.LEFT)

        tk.Button(
            bottom_row,
            text="恢复原壁纸",
            font=("Microsoft YaHei UI", 9),
            width=11,
            pady=4,
            cursor="hand2",
            command=self.restore_wallpaper
        ).pack(side=tk.RIGHT)

    def get_default_scale(self, img_w, img_h):
        return min(self.screen_w / img_w, self.screen_h / img_h)

    def load_image_settings(self, filename):
        img_path = os.path.join(self.wallpaper_dir, filename)
        size = self.engine.get_image_size(img_path)
        img_w, img_h = size if size else (self.screen_w, self.screen_h)

        profiles = self.config.get("profiles", {})
        if filename in profiles:
            p = profiles[filename]
            self.scale = p.get("scale", self.get_default_scale(img_w, img_h))
            self.offset_x = p.get("offset_x", 0)
            self.offset_y = p.get("offset_y", 0)
            self.bg_mode.set(p.get("bg_mode", "black"))
            self.custom_color = p.get("custom_color", "#000000")
        else:
            self.scale = self.get_default_scale(img_w, img_h)
            self.offset_x = 0
            self.offset_y = 0
            self.bg_mode.set("black")
            self.custom_color = "#000000"

        self.color_swatch.config(bg=self.custom_color)

    def save_image_settings(self, filename):
        if "profiles" not in self.config:
            self.config["profiles"] = {}
        self.config["profiles"][filename] = {
            "scale": round(self.scale, 4),
            "offset_x": int(self.offset_x),
            "offset_y": int(self.offset_y),
            "bg_mode": self.bg_mode.get(),
            "custom_color": self.custom_color
        }
        self.save_config()

    def resolve_bg_hex(self, img_path):
        mode = self.bg_mode.get()
        if mode == "black":
            return "#000000"
        elif mode == "custom":
            return self.custom_color
        elif mode == "auto":
            return self.engine.extract_auto_color(img_path)
        return "#000000"

    def update_preview(self):
        if not self.current_filename:
            return
        img_path = os.path.join(self.wallpaper_dir, self.current_filename)
        if not os.path.exists(img_path):
            return

        ratio = self.preview_w / self.screen_w
        bg_hex = self.resolve_bg_hex(img_path)

        ok = self.engine.render_canvas(
            src_path=img_path,
            out_path=self.preview_tmp_path,
            canvas_w=self.preview_w,
            canvas_h=self.preview_h,
            scale=self.scale * ratio,
            offset_x=self.offset_x * ratio,
            offset_y=self.offset_y * ratio,
            bg_hex=bg_hex
        )
        if ok and os.path.exists(self.preview_tmp_path):
            self.tk_preview = tk.PhotoImage(file=self.preview_tmp_path)
            self.canvas.delete("all")
            self.canvas.create_image(0, 0, anchor="nw", image=self.tk_preview)

        total = len(self.images)
        pct = int(self.scale * 100)
        self.status_var.set(
            f"[{self.current_index + 1}/{total}] {self.current_filename}  |  缩放: {pct}%  偏移: ({self.offset_x}, {self.offset_y})"
        )

    def choose_custom_color(self):
        color_code = colorchooser.askcolor(title="选择桌面背景填充颜色", initialcolor=self.custom_color)
        if color_code and color_code[1]:
            self.custom_color = color_code[1]
            self.color_swatch.config(bg=self.custom_color)
        self.on_param_changed()

    def on_param_changed(self):
        self.update_preview()

    def move_image(self, dx, dy):
        self.offset_x += dx
        self.offset_y += dy
        self.update_preview()

    def zoom_image(self, delta):
        self.scale = max(0.05, min(5.0, self.scale + delta))
        self.update_preview()

    def reset_transform(self):
        if not self.current_filename:
            return
        img_path = os.path.join(self.wallpaper_dir, self.current_filename)
        size = self.engine.get_image_size(img_path)
        if size:
            self.scale = self.get_default_scale(size[0], size[1])
        self.offset_x = 0
        self.offset_y = 0
        self.update_preview()

    def preview_step(self, step):
        """仅在预览窗口切换上一张/下一张，加载其记忆参数，不立即修改桌面"""
        self.images = self.scan_images()
        if not self.images:
            self.status_var.set("【壁纸】文件夹内没有图片")
            return

        if self.current_filename in self.images:
            self.current_index = (self.images.index(self.current_filename) + step) % len(self.images)
        else:
            self.current_index = 0

        self.current_filename = self.images[self.current_index]
        self.load_image_settings(self.current_filename)
        self.update_preview()

    def set_windows_wallpaper(self, image_path):
        if image_path and os.path.exists(image_path):
            try:
                key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Control Panel\Desktop", 0, winreg.KEY_SET_VALUE)
                winreg.SetValueEx(key, "WallpaperStyle", 0, winreg.REG_SZ, "0")
                winreg.SetValueEx(key, "TileWallpaper", 0, winreg.REG_SZ, "0")
                winreg.CloseKey(key)
            except Exception:
                pass

            ctypes.windll.user32.SystemParametersInfoW(
                SPI_SETDESKWALLPAPER, 0, image_path, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE
            )
            return True
        return False

    def apply_current_wallpaper(self):
        if not self.current_filename:
            return
        img_path = os.path.join(self.wallpaper_dir, self.current_filename)
        bg_hex = self.resolve_bg_hex(img_path)

        ok = self.engine.render_canvas(
            src_path=img_path,
            out_path=self.rendered_path,
            canvas_w=self.screen_w,
            canvas_h=self.screen_h,
            scale=self.scale,
            offset_x=self.offset_x,
            offset_y=self.offset_y,
            bg_hex=bg_hex
        )
        if ok and self.set_windows_wallpaper(self.rendered_path):
            self.save_image_settings(self.current_filename)
            self.is_restored = False
            self.has_changed_in_session = True
            self.update_preview()

    def next_wallpaper(self):
        self.images = self.scan_images()
        if not self.images:
            self.status_var.set("【壁纸】文件夹内没有图片")
            return

        if self.current_filename in self.images:
            self.current_index = (self.images.index(self.current_filename) + 1) % len(self.images)
        else:
            self.current_index = 0

        self.current_filename = self.images[self.current_index]
        self.load_image_settings(self.current_filename)
        self.apply_current_wallpaper()

    def restore_wallpaper(self):
        if os.path.exists(self.backup_path):
            self.set_windows_wallpaper(self.backup_path)
            self.is_restored = True
            self.status_var.set("已恢复为系统原始壁纸")
        else:
            messagebox.showwarning("提示", "未找到原始壁纸备份文件。")

    def on_closing(self):
        if self.current_filename:
            self.save_config()

        if not self.has_changed_in_session or self.is_restored or not os.path.exists(self.backup_path):
            self.root.destroy()
            return

        answer = messagebox.askyesno("退出确认", "是否恢复原桌面壁纸？")
        if answer:
            self.set_windows_wallpaper(self.backup_path)
        self.root.destroy()


if __name__ == "__main__":
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass

    try:
        root = tk.Tk()
        app = WallpaperChangerPro(root)
        root.mainloop()
    except Exception:
        import traceback
        messagebox.showerror("启动异常", f"程序运行出错：\n{traceback.format_exc()}")